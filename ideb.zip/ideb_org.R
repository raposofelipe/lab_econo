##### ajeitando a base para o IDEB #####

rm(list = ls()) 

library(readxl)
library(dplyr)

# determinando o diretorio

diretorio <- "C:/Users/feref/Downloads/IDEB"
setwd(diretorio)

# puxando e organizando os dados do ideb para o EF2

ideb_af <- read_excel("ideb_af_mun.xlsx")

ideb_af <- ideb_af %>%
  mutate(
    across(starts_with("ideb_"), ~ na_if(., "-")),
    across(starts_with("ideb_"), ~ as.numeric(gsub(",", ".", .))),
    across(starts_with("ideb_"), ~ round(., 1))
  )

# repetindo para o EF1

ideb_ai <- read_excel("ideb_ai_mun.xlsx")

ideb_ai <- ideb_ai %>%
  mutate(
    across(starts_with("ideb_"), ~ na_if(., "-")),
    across(starts_with("ideb_"), ~ as.numeric(gsub(",", ".", .))),
    across(starts_with("ideb_"), ~ round(., 1))
  )

# filtrando apenas pela rede publica

ideb_ai <- ideb_ai %>% filter(rede == "publica")
ideb_af <- ideb_af %>% filter(rede == "publica")


## importante apenas para comparacoes entre os EFs ##
# como possuem obs diferentes, vamos criar um terceiro banco apenas com dados em comum 

ideb_ef <- inner_join(ideb_ai, ideb_af, by = "municipio")

ideb_ef <- ideb_ef %>%
  # - as colunas duplicadas
  select(-"rede.x", -"codigo do municipio.x", -"uf.x") %>%
  # renomeando
  rename(
    rede = "rede.y",
    `codigo do municipio` = "codigo do municipio.y",
    uf = "uf.y"
  ) %>% 
  select( uf, # mantendo apenas as variaveis necessarias para a o ideb do trabalho
            `codigo do municipio`,
             rede,
             municipio,
             ideb_ai_2007,
             ideb_ai_2009,
             ideb_ai_2017,
             ideb_ai_2019,
             ideb_af_2007,
             ideb_af_2009,
             ideb_af_2017,
             ideb_af_2019
          )


# salvando em rda para subir no GitHub

save(ideb_ef, file = paste0(diretorio, "/ideb_ef.Rda"))

