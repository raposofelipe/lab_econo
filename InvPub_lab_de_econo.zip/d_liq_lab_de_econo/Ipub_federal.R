##### ajeitando a base para as despesas federais liquidadas com educacao (2004-08 e 2014-18) #####

rm(list = ls()) 

library(readxl)
library(dplyr)
library(lubridate)
library(labelled)

# determinando o diretorio

diretorio <- "C:\\Users\\feref\\Downloads\\d_liq_lab_de_econo"
setwd(diretorio)

# puxando a base e ajeitando para bilhoes 

d_liq_nom <- read_excel("d_liq_nominais_educ.xlsx") %>%
  mutate(
    d_liq_educ = d_liq_educ / 1e9
  )

# preparando o IGP-DI
igp <- read_excel("igp_di_gv.xlsx") %>%
  mutate(
    Data = my(Data),
    ano = year(Data)
  )

# media anual do IGP-DI, ja que nao se sabe quando as despesas foram liquidadas
igp_anual <- igp %>%
  group_by(ano) %>%
  summarise(igp_medio = mean(IGP_DI, na.rm = TRUE))

# indice base (dez/2019)
igp_base_2019 <- igp %>%
  filter(Data == ymd("2019-12-01")) %>%
  pull(IGP_DI)

# deflacionando os valores nominais
d_defl <- d_liq_nom %>%
  left_join(igp_anual %>% select(ano, igp_medio), by = "ano") %>%
  mutate(
    d_liq_defl = d_liq_educ * (igp_base_2019 / igp_medio)  # deflacionar
  )


# somando as despesas para o período 2004-2008 (referente a 2009) e 2014-2018 (referente a 2019)

d_2009 <- d_defl %>%
  filter(ano %in% 2004:2008) %>%
  summarise(d_2009 = sum(d_liq_defl, na.rm = TRUE))

d_2019 <- d_defl %>%
  filter(ano %in% 2014:2018) %>%
  summarise(d_2019 = sum(d_liq_defl, na.rm = TRUE))

Ipub_fed <-
tibble(
  ano = c(2009, 2019),
  I_educ_fed = c(d_2009$d_2009, d_2019$d_2019)
)

# determinando os rotulos

d_defl <- d_defl %>%
  set_variable_labels(
    ano = "Ano de referência",
    d_liq_educ = "Despesa liquidada em educação (nominal em bilhões de R$)",
    igp_medio = "IGP-DI médio anual",
    d_liq_defl = "Despesa liquidada em educação (em bilhões de R$ de dez/2019)"
  )

Ipub_fed <- Ipub_fed %>%
  set_variable_labels(
    ano = "Ano de referência",
    I_educ_fed = "Investimento Público Federal em Educação (em bilhões de R$ de dez/2019)"
  )

# salvando em rda para subir no GitHub

save(d_liq_nom, igp, d_defl, Ipub_fed, file = paste0(diretorio, "/Ipub_federal.Rda"))
